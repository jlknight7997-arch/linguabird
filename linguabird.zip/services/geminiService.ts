
import { GoogleGenAI, Type } from "@google/genai";
import { Exercise, ExerciseType, Difficulty } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const generateLesson = async (language: string, difficulty: Difficulty): Promise<Exercise[]> => {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Gere uma lição de ${language} (${difficulty}) com 5 exercícios na ordem EXATA:
    1. LEARN: Apresente uma palavra/frase. Prompt em ${language}, targetText é a tradução, context é uma dica de uso.
    2. LISTEN: O usuário ouve ${language} e escolhe a tradução certa entre as 'options'.
    3. PRACTICE: Múltipla escolha no idioma ${language} para completar uma frase.
    4. TRANSLATE: Tradução direta de Português para ${language}.
    5. SPEAK: Uma frase em ${language} para praticar pronúncia.

    Use JSON estrito. Instruções em PT-BR. Nível pedagógico progressivo.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            id: { type: Type.STRING },
            type: { type: Type.STRING, enum: Object.values(ExerciseType) },
            prompt: { type: Type.STRING },
            targetText: { type: Type.STRING },
            audioText: { type: Type.STRING },
            context: { type: Type.STRING },
            options: { type: Type.ARRAY, items: { type: Type.STRING } },
            explanation: { type: Type.STRING }
          },
          required: ["id", "type", "prompt", "targetText"]
        }
      }
    }
  });

  try {
    return JSON.parse(response.text || "[]");
  } catch (e) {
    console.error("Erro ao processar lição:", e);
    return [];
  }
};

export const generateSpeech = async (text: string): Promise<string> => {
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash-preview-tts",
    contents: [{ parts: [{ text: text }] }],
    config: {
      responseModalities: ["AUDIO"],
      speechConfig: {
        voiceConfig: {
          prebuiltVoiceConfig: { voiceName: 'Kore' },
        },
      },
    },
  });
  return response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data || '';
};
