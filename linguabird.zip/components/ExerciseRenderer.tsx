
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Exercise, ExerciseType } from '../types';
import { generateSpeech } from '../services/geminiService';

interface ExerciseRendererProps {
  exercise: Exercise;
  onAnswer: (correct: boolean) => void;
}

export const ExerciseRenderer: React.FC<ExerciseRendererProps> = ({ exercise, onAnswer }) => {
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [inputText, setInputText] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [audioBase64, setAudioBase64] = useState<string | null>(null);
  const [isLoadingAudio, setIsLoadingAudio] = useState(false);
  const [isListening, setIsListening] = useState(false); // Estágio de gravação de voz
  const [isAudioPlaying, setIsAudioPlaying] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const recognitionRef = useRef<any>(null);

  // Inicializa o reconhecimento de voz (Web Speech API)
  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.lang = 'pt-BR'; // Será atualizado dinamicamente conforme o idioma alvo se necessário
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = false;

      recognitionRef.current.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript.toLowerCase();
        const target = (exercise.prompt || '').toLowerCase();
        
        // Comparação simples de proximidade ou igualdade
        const isCorrect = transcript.includes(target) || target.includes(transcript);
        
        setIsListening(false);
        setIsSubmitted(true);
        onAnswer(isCorrect);
      };

      recognitionRef.current.onerror = () => {
        setIsListening(false);
        alert("Não consegui te ouvir. Vamos tentar de novo?");
      };

      recognitionRef.current.onend = () => {
        setIsListening(false);
      };
    }
  }, [exercise, onAnswer]);

  const playAudio = useCallback((base64?: string) => {
    const data = base64 || audioBase64;
    if (!data || isListening) return;

    if (audioRef.current) {
      audioRef.current.pause();
    }

    setIsAudioPlaying(true);
    const audio = new Audio(`data:audio/wav;base64,${data}`);
    audioRef.current = audio;

    audio.onended = () => {
      setIsAudioPlaying(false);
    };

    audio.play().catch(e => {
      console.error("Erro ao reproduzir áudio", e);
      setIsAudioPlaying(false);
    });
  }, [audioBase64, isListening]);

  useEffect(() => {
    // Reset de estado para novo exercício
    setSelectedOption(null);
    setInputText('');
    setIsSubmitted(false);
    setAudioBase64(null);
    setIsListening(false);
    setIsAudioPlaying(false);

    const fetchAndAutoPlay = async () => {
      const textToSpeak = exercise.type === ExerciseType.LEARN ? exercise.prompt : 
                         (exercise.audioText || exercise.prompt);
      
      // Traduções não tocam áudio automático geralmente
      if (textToSpeak && exercise.type !== ExerciseType.TRANSLATE) {
        setIsLoadingAudio(true);
        try {
          const base64 = await generateSpeech(textToSpeak);
          setAudioBase64(base64);
          // Auto-play apenas se for LEARN ou LISTEN para seguir a regra de "escutar primeiro"
          if (exercise.type === ExerciseType.LEARN || exercise.type === ExerciseType.LISTEN || exercise.type === ExerciseType.SPEAK) {
            playAudio(base64);
          }
        } catch (e) {
          console.error("Erro no fetch de áudio", e);
        } finally {
          setIsLoadingAudio(false);
        }
      }
    };

    fetchAndAutoPlay();

    return () => {
      if (audioRef.current) audioRef.current.pause();
      if (recognitionRef.current) recognitionRef.current.stop();
    };
  }, [exercise, playAudio]);

  const handleMicClick = () => {
    if (isAudioPlaying || isSubmitted) return;

    // Garante que o áudio terminou antes de ouvir
    setIsListening(true);
    if (recognitionRef.current) {
      try {
        recognitionRef.current.start();
      } catch (e) {
        console.error("Speech recognition error", e);
        setIsListening(false);
      }
    } else {
      // Fallback para navegadores sem suporte
      setTimeout(() => {
        setIsListening(false);
        setIsSubmitted(true);
        onAnswer(true); // Simula acerto no MVP se não houver API
      }, 2000);
    }
  };

  const handleSubmit = () => {
    if (isSubmitted || isAudioPlaying) return;
    
    let correct = false;
    if (exercise.type === ExerciseType.LEARN) {
      correct = true;
    } else if (exercise.type === ExerciseType.LISTEN || exercise.type === ExerciseType.PRACTICE) {
      correct = selectedOption === exercise.targetText;
    } else if (exercise.type === ExerciseType.TRANSLATE) {
      correct = inputText.trim().toLowerCase() === (exercise.targetText || '').toLowerCase();
    }
    
    setIsSubmitted(true);
    onAnswer(correct);
  };

  const renderContent = () => {
    const interactionDisabled = isAudioPlaying || isSubmitted;

    switch (exercise.type) {
      case ExerciseType.LEARN:
        return (
          <div className="flex flex-col items-center justify-center h-full space-y-8 animate-fadeIn text-center py-10">
            <div className="bg-linguabird-green/10 p-10 rounded-[3rem] border-4 border-linguabird-green/20 w-full shadow-inner relative">
              <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-linguabird-green text-white px-6 py-1 rounded-full text-xs font-black uppercase tracking-widest shadow-md">
                Aprenda agora
              </div>
              <div className="text-7xl mb-6">🦜</div>
              <h3 className="text-5xl font-black text-linguabird-blue mb-2">{exercise.prompt}</h3>
              <p className="text-2xl text-linguabird-green font-bold italic">{exercise.targetText}</p>
              {exercise.context && (
                <div className="mt-8 p-4 bg-white/80 rounded-2xl text-gray-500 font-bold border border-linguabird-green/10">
                  💡 {exercise.context}
                </div>
              )}
            </div>
            <button 
              onClick={() => playAudio()} 
              disabled={isAudioPlaying}
              className={`bg-white border-2 border-gray-100 p-4 rounded-2xl shadow-sm transition-all active:scale-95 ${isAudioPlaying ? 'opacity-50 grayscale' : 'hover:scale-110'}`}
            >
              <span className="text-4xl">{isAudioPlaying ? '🔈' : '🔊'}</span>
              <p className="text-[10px] font-black text-gray-400 mt-1">OUVIR NOVAMENTE</p>
            </button>
          </div>
        );

      case ExerciseType.LISTEN:
        return (
          <div className="mt-8 space-y-8 animate-fadeIn text-center">
            <h2 className="text-2xl font-black text-linguabird-blue leading-tight">Ouça e identifique</h2>
            <button 
              onClick={() => playAudio()} 
              disabled={isAudioPlaying || isLoadingAudio}
              className={`w-40 h-40 rounded-[2.5rem] shadow-xl border-b-8 transition-all flex items-center justify-center mx-auto
                ${isAudioPlaying ? 'bg-gray-400 border-gray-600 cursor-wait' : 'bg-blue-500 border-blue-700 text-white hover:bg-blue-400 active:border-b-0 active:translate-y-2'}`}
            >
              {isLoadingAudio ? <div className="animate-spin rounded-full h-10 w-10 border-4 border-white border-t-transparent" /> : <span className="text-6xl">{isAudioPlaying ? '🔈' : '🔊'}</span>}
            </button>
            <div className={`grid gap-4 mt-12 transition-opacity ${isAudioPlaying ? 'opacity-50 pointer-events-none' : 'opacity-100'}`}>
              {exercise.options?.map((opt, i) => (
                <button
                  key={i}
                  disabled={interactionDisabled}
                  onClick={() => setSelectedOption(opt)}
                  className={`p-6 border-2 rounded-2xl font-bold text-xl transition-all border-b-4 ${selectedOption === opt ? 'border-linguabird-green bg-green-50 text-linguabird-blue' : 'border-gray-100 bg-white hover:border-gray-200'}`}
                >
                  {opt}
                </button>
              ))}
            </div>
            {isAudioPlaying && <p className="text-xs font-black text-blue-500 animate-pulse uppercase tracking-widest">Escutando...</p>}
          </div>
        );

      case ExerciseType.SPEAK:
        return (
          <div className="flex flex-col items-center justify-center h-full space-y-10 animate-fadeIn text-center">
            <h2 className="text-3xl font-black text-linguabird-blue">Repita a frase</h2>
            <div className="p-8 bg-gray-50 rounded-[2.5rem] border-2 border-gray-100 w-full shadow-sm relative">
              <button 
                onClick={() => playAudio()} 
                disabled={isAudioPlaying || isListening}
                className={`absolute top-4 right-4 text-2xl transition-all ${isAudioPlaying ? 'animate-pulse opacity-50' : 'hover:scale-110'}`}
              >
                {isAudioPlaying ? '🔈' : '🔊'}
              </button>
              <p className="text-4xl font-black text-linguabird-blue italic leading-tight">{exercise.prompt}</p>
            </div>
            
            <div className="relative">
              {isListening && <div className="absolute inset-0 bg-red-500/20 rounded-full animate-ping" />}
              <button 
                onClick={handleMicClick}
                disabled={isAudioPlaying || isSubmitted || isListening}
                className={`w-32 h-32 rounded-full flex items-center justify-center text-5xl shadow-2xl transition-all border-b-8
                  ${isListening ? 'bg-red-500 text-white scale-110 border-red-700' : 
                    (isAudioPlaying ? 'bg-gray-200 text-gray-400 border-gray-300 cursor-not-allowed' : 'bg-linguabird-green text-white border-green-700 hover:bg-green-600 active:translate-y-2 active:border-b-0')}`}
              >
                {isListening ? '🛑' : '🎤'}
              </button>
            </div>
            <div className="space-y-2">
              <p className={`font-black uppercase tracking-widest text-sm transition-colors ${isListening ? 'text-red-500 animate-pulse' : (isAudioPlaying ? 'text-blue-500' : 'text-gray-400')}`}>
                {isListening ? 'Ouvindo agora...' : (isAudioPlaying ? 'Ouça o exemplo primeiro' : 'Toque para falar')}
              </p>
              {isAudioPlaying && <div className="flex justify-center gap-1"><div className="w-1 h-4 bg-blue-500 animate-bounce" /><div className="w-1 h-6 bg-blue-500 animate-bounce delay-75" /><div className="w-1 h-4 bg-blue-500 animate-bounce delay-150" /></div>}
            </div>
          </div>
        );

      default:
        return (
          <div className={`mt-8 space-y-6 animate-fadeIn transition-opacity ${isAudioPlaying ? 'opacity-50 pointer-events-none' : 'opacity-100'}`}>
            <h2 className="text-2xl font-black text-linguabird-blue">{exercise.prompt}</h2>
            {exercise.options ? (
              <div className="grid gap-3">
                {exercise.options.map((opt, i) => (
                  <button
                    key={i}
                    disabled={interactionDisabled}
                    onClick={() => setSelectedOption(opt)}
                    className={`p-5 text-left border-2 rounded-[1.5rem] font-bold text-lg border-b-4 transition-all ${selectedOption === opt ? 'border-linguabird-green bg-green-50' : 'border-gray-100 bg-white hover:border-gray-200'}`}
                  >
                    {opt}
                  </button>
                ))}
              </div>
            ) : (
              <textarea
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                disabled={interactionDisabled}
                placeholder="Escreva sua tradução..."
                className="w-full p-6 border-2 border-gray-100 rounded-[2rem] h-40 text-2xl font-black focus:border-linguabird-green outline-none shadow-inner"
              />
            )}
          </div>
        );
    }
  };

  return (
    <div className="flex flex-col h-full p-6 pb-32">
      <div className="flex-1 overflow-y-auto">
        {renderContent()}
      </div>
      <div className="fixed bottom-0 left-0 right-0 p-6 bg-white border-t-2 border-gray-100">
        <button
          onClick={handleSubmit}
          disabled={exercise.type === ExerciseType.SPEAK || isAudioPlaying || (exercise.type !== ExerciseType.LEARN && !selectedOption && !inputText)}
          className={`w-full py-5 rounded-[2rem] font-black text-xl tracking-wide shadow-xl transition-all border-b-8 ${
            (exercise.type === ExerciseType.SPEAK || isAudioPlaying || (exercise.type !== ExerciseType.LEARN && !selectedOption && !inputText))
            ? 'bg-gray-100 text-gray-300 border-gray-200 cursor-not-allowed'
            : 'bg-linguabird-green text-white border-green-700 hover:bg-green-500 active:translate-y-1 active:border-b-4'
          }`}
        >
          {exercise.type === ExerciseType.LEARN ? 'ENTENDI' : (exercise.type === ExerciseType.SPEAK ? 'USE O MICROFONE' : 'VERIFICAR')}
        </button>
      </div>
    </div>
  );
};
