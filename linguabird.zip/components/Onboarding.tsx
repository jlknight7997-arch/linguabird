
import React, { useState } from 'react';
import { Language, UserStats } from '../types';
import { LANGUAGES } from '../constants';

interface OnboardingProps {
  onComplete: (lang: Language, stats: Partial<UserStats>) => void;
}

export const Onboarding: React.FC<OnboardingProps> = ({ onComplete }) => {
  const [step, setStep] = useState(1);
  const [selectedLang, setSelectedLang] = useState<Language | null>(null);
  const [name, setName] = useState('');
  const [goal, setGoal] = useState(10);

  const handleNext = () => {
    if (step < 3) setStep(step + 1);
    else if (selectedLang) {
      onComplete(selectedLang, { name, goal });
    }
  };

  return (
    <div className="flex flex-col h-full p-8 animate-fadeIn">
      <div className="flex justify-center mb-8">
        <div className="text-6xl animate-bounce-slow">🦜</div>
      </div>

      {step === 1 && (
        <div className="space-y-6 animate-fadeIn">
          <h2 className="text-3xl font-black text-[#1B365D] text-center">Qual idioma você quer aprender?</h2>
          <div className="grid grid-cols-2 gap-4">
            {LANGUAGES.map((lang) => (
              <button
                key={lang.code}
                onClick={() => setSelectedLang(lang)}
                className={`p-6 border-2 rounded-3xl transition-all text-center ${
                  selectedLang?.code === lang.code 
                  ? 'border-[#4CAF50] bg-green-50 shadow-md' 
                  : 'border-gray-100 bg-white hover:border-gray-300'
                }`}
              >
                <div className="text-4xl mb-2">{lang.flag}</div>
                <div className="font-black text-gray-700">{lang.name}</div>
              </button>
            ))}
          </div>
        </div>
      )}

      {step === 2 && (
        <div className="space-y-6 animate-fadeIn">
          <h2 className="text-3xl font-black text-[#1B365D] text-center">Como devemos te chamar?</h2>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Seu nome aqui..."
            className="w-full p-6 border-2 border-gray-100 rounded-[2rem] text-xl font-bold focus:border-[#4CAF50] outline-none text-center"
          />
          <p className="text-center text-gray-400 font-bold italic">"O LinguaBird adora fazer novos amigos!"</p>
        </div>
      )}

      {step === 3 && (
        <div className="space-y-6 animate-fadeIn">
          <h2 className="text-3xl font-black text-[#1B365D] text-center">Qual sua meta diária?</h2>
          <div className="space-y-3">
            {[5, 10, 15].map((m) => (
              <button
                key={m}
                onClick={() => setGoal(m)}
                className={`w-full p-6 border-2 rounded-[2rem] text-left flex justify-between items-center transition-all ${
                  goal === m ? 'border-[#4CAF50] bg-green-50' : 'border-gray-100 bg-white'
                }`}
              >
                <span className="font-black text-lg text-gray-700">{m} minutos por dia</span>
                <span className="text-gray-400 font-bold">{m === 5 ? 'Leve' : m === 10 ? 'Regular' : 'Intenso'}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      <div className="mt-auto pt-8">
        <button
          onClick={handleNext}
          disabled={step === 1 && !selectedLang || step === 2 && !name}
          className={`w-full py-5 rounded-[2rem] font-black text-xl transition-all shadow-xl active:scale-95 ${
            (step === 1 && !selectedLang || step === 2 && !name)
            ? 'bg-gray-200 text-gray-400'
            : 'bg-[#4CAF50] text-white hover:bg-[#43a047]'
          }`}
        >
          {step === 3 ? 'COMEÇAR JORNADA' : 'CONTINUAR'}
        </button>
      </div>
    </div>
  );
};
