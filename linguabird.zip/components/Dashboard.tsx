
import React, { useState, useMemo } from 'react';
import { Language, Difficulty, UserStats, AppState } from '../types';

interface DashboardProps {
  stats: UserStats;
  currentLanguage: Language | null;
  onStartLesson: (lang: Language, difficulty: Difficulty) => void;
  onChangeLanguage: () => void;
  setAppState: (state: AppState) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ stats, currentLanguage, onStartLesson, onChangeLanguage, setAppState }) => {
  const levels = useMemo(() => [
    { id: 1, icon: '🏠', title: 'Fundamentos', color: 'bg-green-500', difficulty: Difficulty.FACIL },
    { id: 2, icon: '🍕', title: 'Comida', color: 'bg-green-500', difficulty: Difficulty.FACIL },
    { id: 3, icon: '✈️', title: 'Viagem', color: 'bg-blue-500', difficulty: Difficulty.MEDIO },
    { id: 4, icon: '💼', title: 'Carreira', color: 'bg-blue-500', difficulty: Difficulty.MEDIO },
    { id: 5, icon: '🗣️', title: 'Conversação', color: 'bg-purple-600', difficulty: Difficulty.DIFICIL },
  ], []);

  if (!currentLanguage) return null;

  return (
    <div className="p-6 pb-24 space-y-8 animate-fadeIn">
      <section className="bg-[#1B365D] rounded-[2.5rem] p-8 text-white relative overflow-hidden shadow-2xl">
        <div className="relative z-10">
          <div className="flex justify-between items-start mb-4">
            <div>
              <h1 className="text-3xl font-black leading-tight">Olá, {stats.name || 'Aluno'}!</h1>
              <p className="text-blue-100 font-bold">Bora bater sua meta diária?</p>
            </div>
            <button 
              onClick={onChangeLanguage}
              className="bg-white/10 hover:bg-white/20 p-2 rounded-2xl transition-colors text-2xl"
            >
              {currentLanguage.flag}
            </button>
          </div>
          
          <div className="flex gap-3">
             <div className="bg-white/20 px-4 py-2 rounded-2xl flex items-center gap-2 border border-white/10">
              <span className="text-xl">🏆</span>
              <span className="font-black text-sm uppercase">Nível {stats.currentLevel}</span>
            </div>
            <div className="bg-white/20 px-4 py-2 rounded-2xl flex items-center gap-2 border border-white/10">
              <span className="text-xl">🔥</span>
              <span className="font-black text-sm uppercase">{stats.streak} Dias</span>
            </div>
          </div>
        </div>
        <div className="absolute right-[-10px] bottom-[-20px] text-[120px] opacity-20 pointer-events-none transform rotate-12">
          🦜
        </div>
      </section>

      <div className="flex flex-col items-center gap-12 py-4">
        {levels.map((level, idx) => (
          <div key={level.id} className="relative flex flex-col items-center group">
            {idx < levels.length - 1 && (
              <div className="absolute top-16 w-1 h-20 bg-gray-100 -z-10 group-hover:bg-green-100 transition-colors" />
            )}
            
            <button
              onClick={() => onStartLesson(currentLanguage, level.difficulty)}
              className={`w-24 h-24 ${level.color} rounded-[2rem] flex items-center justify-center text-4xl shadow-lg border-b-8 border-black/10 active:border-b-0 active:translate-y-1 transition-all hover:scale-110`}
            >
              {level.icon}
            </button>
            <div className="mt-3 text-center">
              <div className="font-black text-[#1B365D] uppercase text-xs tracking-widest">{level.title}</div>
              <div className="text-[10px] font-black text-gray-400 uppercase">{level.difficulty}</div>
            </div>
          </div>
        ))}
      </div>

      <div className="fixed bottom-6 left-1/2 -translate-x-1/2 w-[90%] max-w-md flex justify-around p-4 bg-white border-2 border-gray-100 rounded-3xl shadow-2xl z-40">
        <button 
          onClick={() => setAppState(AppState.DASHBOARD)}
          className="text-3xl hover:scale-110 transition-transform p-2 rounded-2xl bg-green-50"
        >
          🏠
        </button>
        <button 
          onClick={() => setAppState(AppState.PROFILE)}
          className="text-3xl opacity-50 hover:opacity-100 transition-all p-2 rounded-2xl hover:bg-gray-50"
        >
          👤
        </button>
      </div>
    </div>
  );
};
