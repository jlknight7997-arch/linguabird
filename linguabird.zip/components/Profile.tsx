
import React from 'react';
import { UserStats, Language } from '../types';

interface ProfileProps {
  stats: UserStats;
  language: Language | null;
  onReset: () => void;
}

export const Profile: React.FC<ProfileProps> = ({ stats, language, onReset }) => {
  const achievements = [
    { id: 1, title: 'Iniciante Ativo', icon: '🐣', unlocked: true },
    { id: 2, title: 'Fogo nos Estudos', icon: '🔥', unlocked: stats.streak >= 3 },
    { id: 3, title: 'Mestre da Língua', icon: '🎓', unlocked: stats.currentLevel >= 5 },
    { id: 4, title: 'Colecionador', icon: '💰', unlocked: stats.coins >= 100 },
  ];

  return (
    <div className="p-6 space-y-8 animate-fadeIn pb-24">
      <section className="flex flex-col items-center text-center space-y-4">
        <div className="relative">
          <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center text-5xl border-4 border-[#4CAF50] shadow-xl">
            👤
          </div>
          <div className="absolute -bottom-2 -right-2 text-3xl">🦜</div>
        </div>
        <div>
          <h2 className="text-3xl font-black text-[#1B365D]">{stats.name || 'Estudante'}</h2>
          <p className="text-gray-400 font-bold uppercase tracking-widest text-xs">Membro desde Hoje</p>
        </div>
      </section>

      <section className="grid grid-cols-2 gap-4">
        <div className="bg-white border-2 border-gray-100 p-6 rounded-3xl flex flex-col items-center text-center">
          <span className="text-3xl mb-1">⚡</span>
          <span className="text-2xl font-black text-[#1B365D]">{stats.xp}</span>
          <span className="text-[10px] font-black text-gray-400 uppercase">XP Total</span>
        </div>
        <div className="bg-white border-2 border-gray-100 p-6 rounded-3xl flex flex-col items-center text-center">
          <span className="text-3xl mb-1">⭐</span>
          <span className="text-2xl font-black text-[#1B365D]">{stats.currentLevel}</span>
          <span className="text-[10px] font-black text-gray-400 uppercase">Nível</span>
        </div>
      </section>

      <section>
        <h3 className="text-xl font-black text-[#1B365D] mb-4 flex items-center gap-2">
          <span className="w-2 h-6 bg-yellow-400 rounded-full"></span>
          Conquistas
        </h3>
        <div className="grid grid-cols-4 gap-4">
          {achievements.map((a) => (
            <div 
              key={a.id} 
              className={`flex flex-col items-center gap-1 transition-all ${a.unlocked ? 'opacity-100 scale-100' : 'opacity-30 grayscale scale-90'}`}
              title={a.title}
            >
              <div className="w-14 h-14 bg-white border-2 border-gray-100 rounded-2xl flex items-center justify-center text-2xl shadow-sm">
                {a.icon}
              </div>
              <span className="text-[8px] font-black text-center leading-tight uppercase">{a.title}</span>
            </div>
          ))}
        </div>
      </section>

      <section className="pt-8">
        <button 
          onClick={onReset}
          className="w-full py-4 text-red-500 font-black uppercase tracking-widest text-sm hover:bg-red-50 rounded-2xl transition-colors border-2 border-transparent hover:border-red-100"
        >
          Sair e Resetar Perfil
        </button>
      </section>
    </div>
  );
};
