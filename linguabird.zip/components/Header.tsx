
import React from 'react';
import { UserStats } from '../types';

interface HeaderProps {
  stats: UserStats;
  onExit?: () => void;
  showProgress?: boolean;
  progressPercent?: number;
}

export const Header: React.FC<HeaderProps> = ({ stats, onExit, showProgress, progressPercent = 0 }) => {
  return (
    <header className="sticky top-0 z-50 bg-white border-b-2 border-gray-100 p-4 flex items-center justify-between shadow-sm">
      <div className="flex items-center gap-3 flex-1">
        {onExit ? (
          <button onClick={onExit} className="p-2 hover:bg-gray-100 rounded-full transition-colors text-gray-400">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        ) : (
          <div className="flex items-center gap-2">
            <div className="text-3xl relative">
              <span>🦜</span>
              <span className="absolute -top-1 -right-1 text-[10px]">🤓</span>
            </div>
            <div className="hidden sm:flex text-xl font-black tracking-tight leading-none">
              <span style={{ color: '#1B365D' }}>Lingua</span>
              <span style={{ color: '#4CAF50' }}>Bird</span>
            </div>
          </div>
        )}
        
        {showProgress && (
          <div className="flex-1 max-w-[200px] h-3 bg-gray-100 rounded-full overflow-hidden ml-2">
            <div 
              className="h-full bg-green-500 transition-all duration-500 ease-out"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        )}
      </div>

      <div className="flex items-center gap-2 font-black">
        <div className="flex items-center gap-1 text-orange-500 bg-orange-50 px-2 py-1 rounded-xl">
          <span className="text-base">🔥</span>
          <span className="text-xs">{stats.streak}</span>
        </div>
        <div className="flex items-center gap-1 text-yellow-600 bg-yellow-50 px-2 py-1 rounded-xl">
          <span className="text-base">🪙</span>
          <span className="text-xs">{stats.coins}</span>
        </div>
        <div className="flex items-center gap-1 text-red-500 bg-red-50 px-2 py-1 rounded-xl">
          <span className="text-base">❤️</span>
          <span className="text-xs">{stats.hearts}</span>
        </div>
      </div>
    </header>
  );
};
