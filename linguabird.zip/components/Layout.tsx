
import React from 'react';

export const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  return (
    <div className="min-h-screen flex flex-col max-w-2xl mx-auto bg-white shadow-xl md:my-4 md:rounded-3xl overflow-hidden relative">
      {children}
    </div>
  );
};
